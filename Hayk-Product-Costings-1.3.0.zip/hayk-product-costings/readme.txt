=== Hayk Product Costings ===
Author: KrullDNA
Version: 1.0.0
Requires: WordPress + Elementor (front-end widgets). JetEngine used for the CPTs.

A shoe-product costing tool, adapted from the Apotheca cosmetic Product
Costings plugin using the same underlying logic (bulk pricing + a repeater
on Products that pulls live data from a raw-material CPT).

== What it does ==

Materials CPT (slug: `materials`)
  * "Bulk Pricing" metabox — set a purchase Unit (piece/s, m², pair/s …) and
    one or more quantity breaks. Each break is an MOQ (quantity) and the total
    Cost per MOQ. The per-unit rate (Cost ÷ MOQ) is shown live. Add multiple
    breaks for volume discounts.
  * "Where Used" metabox — every product that uses the material.

Products CPT (slug: `products`)
  * "Materials" repeater — one row per material used in the shoe. Columns:
    Material Type (free label, e.g. Leather / Lining / Sole), Material (live
    search of the Materials CPT), Cost per MOQ and MOQ (pulled from the
    material's bulk pricing), Qty per pair (entered), Cost per pair (computed).
  * "Production & Costs" metabox — Production run (pairs), Packaging cost per
    pair, Labour costs (run total), Facility running costs (run total).
  * "Cost Summary" metabox — live figures matching the front end.

Elementor widgets
  * "Materials Table" — the styled front-end table (Material Type, Image,
    Materials, Cost per MOQ, MOQ, Qty per pair, Cost per pair).
  * "Cost Metrics" — selectable figures (Production run, Full production cost,
    Single pair cost, Material cost per pair, Prod. run material cost,
    Packaging run total / per pair, Labour, Facility, Manufacturing total),
    each with a label override. Use several instances to build the cards /
    pills in the design.

== Costing model ==

  unit rate      = Cost per MOQ ÷ MOQ            (from bulk pricing)
  cost per pair  = unit rate × Qty per pair
  Material cost per pair  = Σ cost per pair
  Prod. run material cost = Material cost per pair × Production run
  Packaging run total     = Packaging cost per pair × Production run
  Full production cost    = Prod. run material cost + Packaging run total
                            + Labour + Facility running costs
  Single pair cost        = Full production cost ÷ Production run

With multiple bulk-pricing breaks, the break used for a material is the
largest MOQ that the production-run quantity (Qty per pair × Production run)
reaches, floored at the smallest MOQ. A single break always uses that break.

== Notes / assumptions ==

  * CPT slugs default to `materials` and `products`. Override with the
    `hpc_materials_cpt` / `hpc_products_cpt` filters or the matching
    HPC_MATERIALS_CPT / HPC_PRODUCTS_CPT constants if yours differ.
  * Production & Costs fields are stored by this plugin (`_hpc_*` meta). If you
    already have JetEngine/ACF fields named production_run, packaging_cost,
    labour, or facility_running_costs, the calculator falls back to them when
    the plugin field is empty.
  * The material Image uses the material post's featured image.
  * Currency symbol is set under Products → Costings Settings.

== Changelog ==

= 1.3.0 =
* Leather is now costed by AREA (m² or ft²), replacing the skins model.
  Set the material's unit to m² or ft² (the supplier's selling unit) and enter
  the MOQ + cost in that unit. On the product, leather usage (Qty per pair) is
  always entered in m² — the client's metric standard — and a ft² supplier
  price is converted to a per-m² rate automatically (1 ft² = 0.092903 m²).
* Cost Summary → "Leather to buy for this run" reports the total m² needed and
  the equivalent in the supplier's unit (m²/ft²).
* Removed the per-material "average area per skin" field (no longer needed —
  m²↔ft² is a fixed conversion). Default units updated: m², ft², pieces,
  pairs, packs, etc. (skins dropped). Unit conversions are filterable via
  'hpc_unit_m2_factor'.

= 1.2.1 =
* Clearer skins/area costing on the product Materials table: for an
  area-costed material you enter the net area per pair (m²) and the row now
  shows the fraction of a skin used per pair (e.g. "≈ 0.29 skin/pair").
* Cost Summary → Purchasing now reports, per area-costed material: total area
  needed for the run, whole units (skins) to buy, and the spare offcut left
  on the last unit. Per-pair cost still charges only the area used (skins are
  shared across pairs; the run rounds up to whole skins).
* Front-end Materials Table shows the same per-pair skin fraction under the
  Qty per pair value in area mode.

= 1.2.0 =
* Leather / area costing: a material can now be bought by the unit (skins,
  packs) but costed by area. Set "Average area per unit" (e.g. 1.2 m² per
  skin) in Bulk Pricing; enter the net area per pair on the product and the
  tool converts area → skins, works out cost per pair, and reports the whole
  skins to buy for the run (Cost Summary → Purchasing). Materials without an
  area-per-unit are still costed directly in their purchase unit.
* Restored the Production & Costs inputs on the product (Production run,
  Packaging per pair, Labour, Facility, Miscellaneous). These are the cost
  inputs; if a box is left blank and a matching legacy custom field exists,
  that value is used (shown as the placeholder).
* Settings: Purchase Units is now a 3-field repeater (singular / plural /
  units per) with add, remove and drag-to-reorder.

= 1.1.0 =
* Cost fields now read the client's own custom fields: production_run,
  packaging_unit_cost, labour_costs, facility_running_costs, and the new
  miscellaneous_cost (added to Full production cost). The plugin's duplicate
  Production & Costs metabox has been removed to avoid double entry.
* Packaging production-run total = packaging_unit_cost × production_run.
* Leather costing: per-material Wastage % (cutting/consumption allowance) in
  the Bulk Pricing box; a global Leather Margin % in Settings; and a per-row
  "Apply margin" checkbox that uplifts that break's cost as a buffer.
* Purchase Unit is now a managed dropdown (skins, pairs, pieces, packs, m² …)
  editable under Costings Settings, with singular/plural forms and a "units
  per" count (e.g. pairs = 2 units) shown next to quantities.
* Materials Table widget: separate Image Width and Image Height controls.
* Cost Metrics widget: added the Miscellaneous cost metric.

= 1.0.0 =
* Initial release. Adapted from Apotheca Product Costings for shoe production
  costing: Bulk Pricing on Materials, dynamic Materials table on Products,
  per-pair and full production-run cost calculation, Elementor front-end
  widgets.
